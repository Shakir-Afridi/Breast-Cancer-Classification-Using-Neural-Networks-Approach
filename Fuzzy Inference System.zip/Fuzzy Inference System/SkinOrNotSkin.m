function SOrNS = SkinOrNotSkin(data)
    
   fis = readfis('Fis_Skin_nonSkin');
   SOrNS = evalfis(data(:,:), fis);
end
