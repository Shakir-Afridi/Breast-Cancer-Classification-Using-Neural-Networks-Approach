function ycbcr = rgbTOycbcr(RGB)
    ycbcr = rgb2ycbcr(RGB);
    
    a = (ycbcr(:,1)+16);
    b = (ycbcr(:,2)+128);
    c = (ycbcr(:,3)+128);
    
    ycbcr = [a b c];
end
