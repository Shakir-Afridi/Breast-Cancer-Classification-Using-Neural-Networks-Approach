actualData = load('Skin_NonSkin_dataset.txt');

bgrTOrgb = actualData;
bgrTOrgb(:, [1,3]) = bgrTOrgb(:, [3,1]);

inputData = bgrTOrgb(1:end, 1:3);
outputData = bgrTOrgb(:, end);
