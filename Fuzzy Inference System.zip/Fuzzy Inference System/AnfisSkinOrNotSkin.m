function res = AnfisSkinOrNotSkin(data, anfisModel)
    
    res = evalfis(data, anfisModel);
end