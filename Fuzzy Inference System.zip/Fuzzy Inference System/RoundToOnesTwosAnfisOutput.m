function rep = RoundToOnesTwosAnfisOutput(output)
    newMatrix = output;
    for k = 1 : length(output)
        newMatrix(output<=1.5) = 1;
        newMatrix(output>1.5) = 2;
    end
    rep = newMatrix;
end