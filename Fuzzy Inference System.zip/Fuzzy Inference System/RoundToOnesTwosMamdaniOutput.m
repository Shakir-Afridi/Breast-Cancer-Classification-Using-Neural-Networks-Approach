function rep = RoundToOnesTwosMamdaniOutput(output)
    newMatrix = output;
    for k = 1 : length(output)
        newMatrix(output<=0.58) = 1;
        newMatrix(output>0.58) = 2; 
    end
    rep = newMatrix;
end