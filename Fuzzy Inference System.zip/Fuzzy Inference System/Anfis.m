function res = Anfis(data)
    
    res = anfis(data);
end