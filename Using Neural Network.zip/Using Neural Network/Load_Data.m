actualData = load('Skin_NonSkin_dataset.txt');

bgrTOrgb = actualData;
bgrTOrgb(:, [1,3]) = bgrTOrgb(:, [3,1]);

inputData = bgrTOrgb(1:end, 1:3);
outputData = bgrTOrgb(:, end);

SkinDataTrainingInput = inputData(1:35601, 1:3);
SkinDataTrainingOutout = outputData(1:35601);
SkinDataTestingInput = inputData(35602:50859, 1:3);
SkinDataTestingOutput = outputData(35602:50859);

NonSkinDataTrainingInput = inputData(50859:186798, 1:3);
NonSkinDataTrainingOutout = outputData(50859:186798);
NonSkinDataTestingInput = inputData(189798:end, 1:3);
NonSkinDataTestingOutput = outputData(189798:end);

TrainingInput = [SkinDataTrainingInput; NonSkinDataTrainingInput];
TrainingOutput = [SkinDataTrainingOutout; NonSkinDataTrainingOutout];

TestingInput = [SkinDataTestingInput; NonSkinDataTestingInput];
TestingOutput = [SkinDataTestingOutput; NonSkinDataTestingOutput];