function rep = ReplaceOneTwoWithZerosOnes(output)
    newMatrix = output;
    for k = 1 : length(output)
        newMatrix(output==1) = 0;
        newMatrix(output==2) = 1;
    end
    rep = newMatrix;
end