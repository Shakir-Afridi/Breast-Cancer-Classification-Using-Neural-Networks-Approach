function net = Network(TrainingInput, TrainingOutput)
    net = newff(TrainingInput', TrainingOutput', [5 5], {'tansig' 'tansig'}, 'traingdx', 'learngd', 'mse');
    net.trainParam.lr = 0.01;
    net.trainParam.epochs = 1000;
    net.trainParam.goal = 0.01;
    net.trainParam.max_fail=200;
end
