function res = Recognition(actualOutput, predictedOutput)
    
    skin = 0;
    Notskin = 0;
    
    skinRecognized = 0;
    NotskinReconnized = 0;
    
    for k = 1 : length(actualOutput)
       if actualOutput(k) == 0
           skin = skin + 1;
       else 
           Notskin = Notskin + 1;
       end
    end
    
    for j = 1 : length(actualOutput)
        if actualOutput(j) == 0 && predictedOutput(j) == 0
            skinRecognized = skinRecognized + 1;
        end
        if actualOutput(j) == 1 && predictedOutput(j) == 1
            NotskinReconnized = NotskinReconnized + 1;
        end
    end
    res = [skinRecognized/skin NotskinReconnized/Notskin];
end

